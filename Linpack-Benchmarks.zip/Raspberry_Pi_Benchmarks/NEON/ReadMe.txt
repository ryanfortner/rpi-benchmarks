Benchmark linpackPiFSSP is from linpacksp.c in earlier Source
Code folder, compiled with additional parameter -funsafe-math-optimizations
and different #define options - see linpacksp.c 

Same for memSpdPiNEON from memspeed,c, with different option. 

Benchmark linpackPiNEONi uses NEON Intrinsic Functions - see linpackneon.c
Benchmark NeonSpeed uses NEON Intrinsic Functions and compiled code -
see neonspeed.c

