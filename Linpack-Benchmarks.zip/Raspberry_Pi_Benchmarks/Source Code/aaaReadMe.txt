cpuid.c and cpuid.h are used for each benchmarl compilation.
Dhrystone benchmark uses dhry_1.c, dhry_2.c and dhry.h

Benchmark comments include commands used to compile for 
original RPi and RPi 2, and alternative string to be used
in results log, to show which version was used.


 